package bg.sofia.uni.fmi.mjt.vehiclerent.driver;

public record Driver(AgeGroup ageGroup){}
