package bg.sofia.uni.fmi.mjt.olympics;

import bg.sofia.uni.fmi.mjt.olympics.competition.Competition;
import bg.sofia.uni.fmi.mjt.olympics.competition.CompetitionResultFetcher;
import bg.sofia.uni.fmi.mjt.olympics.competitor.Athlete;
import bg.sofia.uni.fmi.mjt.olympics.competitor.Competitor;
import bg.sofia.uni.fmi.mjt.olympics.competitor.Medal;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class MJTOlympicsTest {
    @Mock
    private CompetitionResultFetcher competitionResultFetcher;

    private Set<Competitor> competitors;

    @Mock
    private Map<String, EnumMap<Medal, Integer>> nationsMedalTable;

    private Olympics olympics;

    @BeforeEach
    void setUp() {
        competitors = new HashSet<>();
        competitors.add(new Athlete("001", "Miao Tsa", "Chinese"));
        competitors.add(new Athlete("002", "Jose Zuniga", "Mexican"));
        competitors.add(new Athlete("002", "Jose Zuniga", "Uruguayan"));

        olympics = new MJTOlympics(competitors, competitionResultFetcher);
    }

    @Test
    void testValidateNullNationality() {
        assertThrows(IllegalArgumentException.class, () -> olympics.getTotalMedals(null));
    }

    @Test
    void testValidateNotRegisteredNationality() {
        assertThrows(IllegalArgumentException.class, () -> olympics.getTotalMedals("invalid_nationality_that_throws"));
    }

    @Test
    void testValidateNullCompetition() {
        assertThrows(IllegalArgumentException.class, () -> olympics.updateMedalStatistics(null));
    }

    @Test
    void testValidateNotRegisteredCompetitor() {
        Competition competition = new Competition(
            "TUES Gaming Tournament",
            "gaming",
            new HashSet<>()
            );

        assertThrows(IllegalArgumentException.class, () -> olympics.updateMedalStatistics(competition));
    }
}
